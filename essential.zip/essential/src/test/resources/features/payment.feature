Feature: Payment processing via RTP API

  Background:
    Given the system has been seeded with standard test accounts

  Scenario: Successful payment between two active accounts
    Given user "U100" is authenticated with role "ROLE_USER"
    When user "U100" sends a payment of "150.00" USD to "U200" with request id "PR-BDD-001"
    Then the response status is 200
    And the payment status is "COMPLETED"
    And a transactionId is present in the response

  Scenario: Payment rejected due to insufficient funds
    Given user "U300" is authenticated with role "ROLE_USER"
    When user "U300" sends a payment of "500.00" USD to "U200" with request id "PR-BDD-002"
    Then the response status is 200
    And the payment status is "REJECTED"
    And the reason code is "INSUFFICIENT_FUNDS"

  Scenario: Payment rejected when receiver account is blocked
    Given user "U100" is authenticated with role "ROLE_USER"
    When user "U100" sends a payment of "50.00" USD to "U_BLOCKED" with request id "PR-BDD-003"
    Then the response status is 200
    And the payment status is "REJECTED"
    And the reason code is "ACCOUNT_BLOCKED"

  Scenario: Analyst can retrieve failed transactions
    Given user "ANALYST1" is authenticated with role "ROLE_ANALYST"
    When the analyst queries failed transactions from "2026-01-01" to "2026-12-31"
    Then the response status is 200
    And the failed transactions list is present

  Scenario: User can query their own balance
    Given user "U100" is authenticated with role "ROLE_USER"
    When user "U100" queries their balance
    Then the response status is 200
    And the balance response contains a currentBalance