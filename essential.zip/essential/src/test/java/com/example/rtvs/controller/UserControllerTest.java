package com.example.rtvs.controller;

import com.example.rtvs.dto.BalanceResponse;
import com.example.rtvs.dto.TransactionHistoryResponse;
import com.example.rtvs.service.BalanceService;
import com.example.rtvs.service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class UserControllerTest {

    @Autowired
    private WebApplicationContext context;

    @MockitoBean
    private BalanceService balanceService;

    @MockitoBean
    private TransactionService transactionService;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(SecurityMockMvcConfigurers.springSecurity())
                .build();
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void getBalance_ownAccount_returns200() throws Exception {
        when(balanceService.getBalance("U100")).thenReturn(
                BalanceResponse.builder()
                        .userId("U100")
                        .currentBalance(new BigDecimal("500.00"))
                        .dailyLimit(new BigDecimal("2000.00"))
                        .build()
        );

        mockMvc.perform(get("/api/v1/rtp/users/U100/balance"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value("U100"))
                .andExpect(jsonPath("$.currentBalance").value(500.00));
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void getBalance_otherAccount_returns403() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/users/U200/balance"))
                .andExpect(status().isForbidden());
    }

    @Test
    void getBalance_noAuthentication_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/users/U100/balance"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void getTransactions_ownAccount_returns200() throws Exception {
        when(transactionService.getTransactionHistory(eq("U100"), any(), any())).thenReturn(
                TransactionHistoryResponse.builder()
                        .transactions(List.of())
                        .build()
        );

        mockMvc.perform(get("/api/v1/rtp/users/U100/transactions")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.transactions").isArray());
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void getTransactions_otherAccount_returns403() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/users/U200/transactions")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isForbidden());
    }

    @Test
    void getTransactions_noAuthentication_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/users/U100/transactions")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isUnauthorized());
    }
}
