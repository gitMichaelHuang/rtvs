package com.example.rtvs.service;

import com.example.rtvs.domain.UserAccount;
import com.example.rtvs.dto.PaymentRequest;
import com.example.rtvs.enums.AccountStatus;
import com.example.rtvs.enums.FailureReasonCode;
import com.example.rtvs.enums.TransactionStatus;
import com.example.rtvs.exception.RtvsException;
import com.example.rtvs.repository.RtpTransactionRepository;
import com.example.rtvs.repository.UserAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ValidationEngineTest {

    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private RtpTransactionRepository transactionRepository;

    @InjectMocks
    private ValidationEngine validationEngine;

    private PaymentRequest request;
    private UserAccount activeSender;
    private UserAccount activeReceiver;

    @BeforeEach
    void setup() {
        request = new PaymentRequest();
        request.setPaymentRequestId("PR-001");
        request.setSenderId("U100");
        request.setReceiverId("U200");
        request.setAmount(new BigDecimal("100.00"));
        request.setCurrency("USD");

        activeSender = UserAccount.builder()
                .userId("U100")
                .currentBalance(new BigDecimal("500.00"))
                .dailyLimit(new BigDecimal("2000.00"))
                .status(AccountStatus.ACTIVE)
                .password("hash")
                .role("ROLE_USER")
                .build();

        activeReceiver = UserAccount.builder()
                .userId("U200")
                .currentBalance(new BigDecimal("100.00"))
                .dailyLimit(new BigDecimal("1000.00"))
                .status(AccountStatus.ACTIVE)
                .password("hash")
                .role("ROLE_USER")
                .build();
    }

    @Test
    void validate_success_returnsLockedSender() {
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));
        when(userAccountRepository.findById("U200")).thenReturn(Optional.of(activeReceiver));
        when(userAccountRepository.findByIdForUpdate("U100")).thenReturn(Optional.of(activeSender));
        when(transactionRepository.sumDailyAmount(eq("U100"), any(), eq(TransactionStatus.COMPLETED)))
                .thenReturn(BigDecimal.ZERO);

        UserAccount result = validationEngine.validate(request);

        assertThat(result.getUserId()).isEqualTo("U100");
    }

    @Test
    void validate_nullAmount_throwsInvalidAmount() {
        request.setAmount(null);

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.INVALID_AMOUNT));
    }

    @Test
    void validate_zeroAmount_throwsInvalidAmount() {
        request.setAmount(BigDecimal.ZERO);

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.INVALID_AMOUNT));
    }

    @Test
    void validate_negativeAmount_throwsInvalidAmount() {
        request.setAmount(new BigDecimal("-10.00"));

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.INVALID_AMOUNT));
    }

    @Test
    void validate_senderNotFound_throwsSenderNotFound() {
        when(userAccountRepository.findById("U100")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.SENDER_NOT_FOUND));
    }

    @Test
    void validate_senderBlocked_throwsAccountBlocked() {
        activeSender.setStatus(AccountStatus.BLOCKED);
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.ACCOUNT_BLOCKED));
    }

    @Test
    void validate_receiverNotFound_throwsReceiverNotFound() {
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));
        when(userAccountRepository.findById("U200")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.RECEIVER_NOT_FOUND));
    }

    @Test
    void validate_receiverBlocked_throwsAccountBlocked() {
        activeReceiver.setStatus(AccountStatus.BLOCKED);
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));
        when(userAccountRepository.findById("U200")).thenReturn(Optional.of(activeReceiver));

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.ACCOUNT_BLOCKED));
    }

    @Test
    void validate_insufficientBalance_throwsInsufficientFunds() {
        request.setAmount(new BigDecimal("1000.00"));
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));
        when(userAccountRepository.findById("U200")).thenReturn(Optional.of(activeReceiver));
        when(userAccountRepository.findByIdForUpdate("U100")).thenReturn(Optional.of(activeSender));

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.INSUFFICIENT_FUNDS));
    }

    @Test
    void validate_dailyLimitExceeded_throwsDailyLimitExceeded() {
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(activeSender));
        when(userAccountRepository.findById("U200")).thenReturn(Optional.of(activeReceiver));
        when(userAccountRepository.findByIdForUpdate("U100")).thenReturn(Optional.of(activeSender));
        when(transactionRepository.sumDailyAmount(eq("U100"), any(), eq(TransactionStatus.COMPLETED)))
                .thenReturn(new BigDecimal("1950.00"));

        assertThatThrownBy(() -> validationEngine.validate(request))
                .isInstanceOf(RtvsException.class)
                .satisfies(e -> assertThat(((RtvsException) e).getReasonCode())
                        .isEqualTo(FailureReasonCode.DAILY_LIMIT_EXCEEDED));
    }
}
