package com.example.rtvs.controller;

import com.example.rtvs.dto.PaymentResponse;
import com.example.rtvs.enums.TransactionStatus;
import com.example.rtvs.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class PaymentControllerV2Test {

    @Autowired
    private WebApplicationContext context;

    @MockitoBean
    private PaymentService paymentService;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(SecurityMockMvcConfigurers.springSecurity())
                .build();
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePaymentV2_standardMode_returnsCompletionSeconds5() throws Exception {
        when(paymentService.processPayment(any(), eq("U100"))).thenReturn(
                PaymentResponse.builder()
                        .transactionId("TX-V2-001")
                        .status(TransactionStatus.COMPLETED.name())
                        .postedAt(Instant.now())
                        .build()
        );

        mockMvc.perform(post("/api/v2/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "paymentRequestId": "PR-V2-001",
                                  "senderId": "U100",
                                  "receiverId": "U200",
                                  "amount": 100.00,
                                  "currency": "USD",
                                  "processingMode": "STANDARD"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.transactionId").value("TX-V2-001"))
                .andExpect(jsonPath("$.status").value("COMPLETED"))
                .andExpect(jsonPath("$.processingMode").value("STANDARD"))
                .andExpect(jsonPath("$.estimatedCompletionSeconds").value(5));
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePaymentV2_expressMode_returnsCompletionSeconds1() throws Exception {
        when(paymentService.processPayment(any(), eq("U100"))).thenReturn(
                PaymentResponse.builder()
                        .transactionId("TX-V2-002")
                        .status(TransactionStatus.COMPLETED.name())
                        .postedAt(Instant.now())
                        .build()
        );

        mockMvc.perform(post("/api/v2/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "paymentRequestId": "PR-V2-002",
                                  "senderId": "U100",
                                  "receiverId": "U200",
                                  "amount": 100.00,
                                  "currency": "USD",
                                  "processingMode": "EXPRESS"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.processingMode").value("EXPRESS"))
                .andExpect(jsonPath("$.estimatedCompletionSeconds").value(1));
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePaymentV2_rejected_noCompletionSeconds() throws Exception {
        when(paymentService.processPayment(any(), eq("U100"))).thenReturn(
                PaymentResponse.builder()
                        .transactionId("TX-V2-003")
                        .status(TransactionStatus.REJECTED.name())
                        .reasonCode("INSUFFICIENT_FUNDS")
                        .build()
        );

        mockMvc.perform(post("/api/v2/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "paymentRequestId": "PR-V2-003",
                                  "senderId": "U100",
                                  "receiverId": "U200",
                                  "amount": 99999.00,
                                  "currency": "USD"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("REJECTED"))
                .andExpect(jsonPath("$.estimatedCompletionSeconds").doesNotExist());
    }

    @Test
    void initiatePaymentV2_noAuthentication_returns401() throws Exception {
        mockMvc.perform(post("/api/v2/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "paymentRequestId": "PR-V2-004",
                                  "senderId": "U100",
                                  "receiverId": "U200",
                                  "amount": 100.00,
                                  "currency": "USD"
                                }
                                """))
                .andExpect(status().isUnauthorized());
    }
}
