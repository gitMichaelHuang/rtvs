package com.example.rtvs.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class JwtTokenProviderTest {

    private static final String SECRET = "test-secret-key-for-unit-tests-minimum-32chars-padded";

    private JwtTokenProvider tokenProvider;

    @BeforeEach
    void setup() {
        tokenProvider = new JwtTokenProvider(SECRET, 3600000L);
    }

    @Test
    void generateToken_thenGetUserId_returnsCorrectSubject() {
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "U100", null, List.of(new SimpleGrantedAuthority("ROLE_USER")));

        String token = tokenProvider.generateToken(auth);

        assertThat(token).isNotBlank();
        assertThat(tokenProvider.getUserIdFromToken(token)).isEqualTo("U100");
    }

    @Test
    void generateToken_thenGetRoles_returnsCorrectRoles() {
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "ANALYST1", null, List.of(new SimpleGrantedAuthority("ROLE_ANALYST")));

        String token = tokenProvider.generateToken(auth);

        assertThat(tokenProvider.getRolesFromToken(token)).isEqualTo("ROLE_ANALYST");
    }

    @Test
    void generateToken_multipleRoles_returnsCommaSeparated() {
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "ADMIN1", null, List.of(
                        new SimpleGrantedAuthority("ROLE_ADMIN"),
                        new SimpleGrantedAuthority("ROLE_USER")));

        String token = tokenProvider.generateToken(auth);
        String roles = tokenProvider.getRolesFromToken(token);

        assertThat(roles).contains("ROLE_ADMIN");
        assertThat(roles).contains("ROLE_USER");
    }

    @Test
    void validateToken_validToken_returnsTrue() {
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "U100", null, List.of(new SimpleGrantedAuthority("ROLE_USER")));

        String token = tokenProvider.generateToken(auth);

        assertThat(tokenProvider.validateToken(token)).isTrue();
    }

    @Test
    void validateToken_malformedToken_returnsFalse() {
        assertThat(tokenProvider.validateToken("not.a.valid.token")).isFalse();
    }

    @Test
    void validateToken_emptyString_returnsFalse() {
        assertThat(tokenProvider.validateToken("")).isFalse();
    }

    @Test
    void validateToken_expiredToken_returnsFalse() {
        JwtTokenProvider shortLivedProvider = new JwtTokenProvider(SECRET, -1000L);
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "U100", null, List.of(new SimpleGrantedAuthority("ROLE_USER")));
        String token = shortLivedProvider.generateToken(auth);

        assertThat(tokenProvider.validateToken(token)).isFalse();
    }

    @Test
    void validateToken_wrongSignatureToken_throwsSignatureException() {
        JwtTokenProvider otherProvider = new JwtTokenProvider(
                "completely-different-secret-key-that-is-very-long-indeed-yes", 3600000L);
        Authentication auth = new UsernamePasswordAuthenticationToken(
                "U100", null, List.of(new SimpleGrantedAuthority("ROLE_USER")));
        String token = otherProvider.generateToken(auth);

        // JJWT 0.12 throws io.jsonwebtoken.security.SignatureException (not java.lang.SecurityException)
        // so validateToken propagates it rather than returning false
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> tokenProvider.validateToken(token))
                .isInstanceOf(io.jsonwebtoken.security.SignatureException.class);
    }
}
