package com.example.rtvs.service;

import com.example.rtvs.domain.UserAccount;
import com.example.rtvs.dto.BalanceResponse;
import com.example.rtvs.enums.AccountStatus;
import com.example.rtvs.exception.ResourceNotFoundException;
import com.example.rtvs.repository.UserAccountRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BalanceServiceTest {

    @Mock
    private UserAccountRepository userAccountRepository;

    @InjectMocks
    private BalanceService balanceService;

    @Test
    void getBalance_existingUser_returnsBalanceResponse() {
        UserAccount account = UserAccount.builder()
                .userId("U100")
                .currentBalance(new BigDecimal("500.00"))
                .dailyLimit(new BigDecimal("2000.00"))
                .status(AccountStatus.ACTIVE)
                .password("hashed")
                .role("ROLE_USER")
                .build();
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(account));

        BalanceResponse response = balanceService.getBalance("U100");

        assertThat(response.getUserId()).isEqualTo("U100");
        assertThat(response.getCurrentBalance()).isEqualByComparingTo("500.00");
        assertThat(response.getDailyLimit()).isEqualByComparingTo("2000.00");
    }

    @Test
    void getBalance_unknownUser_throwsResourceNotFoundException() {
        when(userAccountRepository.findById("UNKNOWN")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> balanceService.getBalance("UNKNOWN"))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("UNKNOWN");
    }
}
