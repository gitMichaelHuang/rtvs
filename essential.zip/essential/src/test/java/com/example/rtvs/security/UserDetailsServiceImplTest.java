package com.example.rtvs.security;

import com.example.rtvs.domain.UserAccount;
import com.example.rtvs.enums.AccountStatus;
import com.example.rtvs.repository.UserAccountRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserDetailsServiceImplTest {

    @Mock
    private UserAccountRepository userAccountRepository;

    @InjectMocks
    private UserDetailsServiceImpl userDetailsService;

    @Test
    void loadUserByUsername_activeUser_returnsUnlockedUserDetails() {
        UserAccount account = UserAccount.builder()
                .userId("U100")
                .password("hashed-password")
                .role("ROLE_USER")
                .status(AccountStatus.ACTIVE)
                .currentBalance(BigDecimal.TEN)
                .dailyLimit(BigDecimal.TEN)
                .build();
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(account));

        UserDetails details = userDetailsService.loadUserByUsername("U100");

        assertThat(details.getUsername()).isEqualTo("U100");
        assertThat(details.getPassword()).isEqualTo("hashed-password");
        assertThat(details.isAccountNonLocked()).isTrue();
        assertThat(details.getAuthorities()).extracting("authority")
                .containsExactly("ROLE_USER");
    }

    @Test
    void loadUserByUsername_blockedUser_returnsLockedUserDetails() {
        UserAccount account = UserAccount.builder()
                .userId("U_BLOCKED")
                .password("hashed-password")
                .role("ROLE_USER")
                .status(AccountStatus.BLOCKED)
                .currentBalance(BigDecimal.TEN)
                .dailyLimit(BigDecimal.TEN)
                .build();
        when(userAccountRepository.findById("U_BLOCKED")).thenReturn(Optional.of(account));

        UserDetails details = userDetailsService.loadUserByUsername("U_BLOCKED");

        assertThat(details.isAccountNonLocked()).isFalse();
    }

    @Test
    void loadUserByUsername_analystUser_returnsAnalystRole() {
        UserAccount account = UserAccount.builder()
                .userId("ANALYST1")
                .password("hashed-password")
                .role("ROLE_ANALYST")
                .status(AccountStatus.ACTIVE)
                .currentBalance(BigDecimal.ZERO)
                .dailyLimit(BigDecimal.ZERO)
                .build();
        when(userAccountRepository.findById("ANALYST1")).thenReturn(Optional.of(account));

        UserDetails details = userDetailsService.loadUserByUsername("ANALYST1");

        assertThat(details.getAuthorities()).extracting("authority")
                .containsExactly("ROLE_ANALYST");
    }

    @Test
    void loadUserByUsername_userNotFound_throwsUsernameNotFoundException() {
        when(userAccountRepository.findById("UNKNOWN")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> userDetailsService.loadUserByUsername("UNKNOWN"))
                .isInstanceOf(UsernameNotFoundException.class)
                .hasMessageContaining("UNKNOWN");
    }
}
