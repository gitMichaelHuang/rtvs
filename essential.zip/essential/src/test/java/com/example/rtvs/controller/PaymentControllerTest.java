package com.example.rtvs.controller;

import com.example.rtvs.dto.PaymentResponse;
import com.example.rtvs.enums.TransactionStatus;
import com.example.rtvs.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class PaymentControllerTest {

    @Autowired
    private WebApplicationContext context;

    @MockitoBean
    private PaymentService paymentService;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(SecurityMockMvcConfigurers.springSecurity())
                .build();
    }

    private static final String PAYMENT_BODY = """
            {
              "paymentRequestId": "PR-001",
              "senderId": "U100",
              "receiverId": "U200",
              "amount": 100.00,
              "currency": "USD"
            }
            """;

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePayment_success_returns200Completed() throws Exception {
        when(paymentService.processPayment(any(), eq("U100"))).thenReturn(
                PaymentResponse.builder()
                        .transactionId("TX-001")
                        .status(TransactionStatus.COMPLETED.name())
                        .postedAt(Instant.now())
                        .build()
        );

        mockMvc.perform(post("/api/v1/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(PAYMENT_BODY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.transactionId").value("TX-001"))
                .andExpect(jsonPath("$.status").value("COMPLETED"));
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePayment_rejected_returns200WithReasonCode() throws Exception {
        when(paymentService.processPayment(any(), eq("U100"))).thenReturn(
                PaymentResponse.builder()
                        .transactionId("TX-002")
                        .status(TransactionStatus.REJECTED.name())
                        .reasonCode("INSUFFICIENT_FUNDS")
                        .message("Sender does not have sufficient balance")
                        .build()
        );

        mockMvc.perform(post("/api/v1/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(PAYMENT_BODY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("REJECTED"))
                .andExpect(jsonPath("$.reasonCode").value("INSUFFICIENT_FUNDS"));
    }

    @Test
    void initiatePayment_noAuthentication_returns401() throws Exception {
        mockMvc.perform(post("/api/v1/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(PAYMENT_BODY))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_ANALYST")
    void initiatePayment_wrongRole_returns403() throws Exception {
        mockMvc.perform(post("/api/v1/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(PAYMENT_BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void initiatePayment_missingAmount_returns400() throws Exception {
        mockMvc.perform(post("/api/v1/rtp/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"senderId\":\"U100\",\"receiverId\":\"U200\",\"currency\":\"USD\"}"))
                .andExpect(status().isBadRequest());
    }
}
