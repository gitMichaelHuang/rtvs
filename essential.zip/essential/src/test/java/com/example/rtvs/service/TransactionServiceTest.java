package com.example.rtvs.service;

import com.example.rtvs.domain.RtpTransaction;
import com.example.rtvs.dto.FailedTransactionsResponse;
import com.example.rtvs.dto.TransactionHistoryResponse;
import com.example.rtvs.enums.FailureReasonCode;
import com.example.rtvs.enums.TransactionStatus;
import com.example.rtvs.repository.RtpTransactionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private RtpTransactionRepository transactionRepository;

    @InjectMocks
    private TransactionService transactionService;

    @Test
    void getTransactionHistory_asSender_returnsDebitDirection() {
        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-001")
                .senderId("U100")
                .receiverId("U200")
                .amount(new BigDecimal("100.00"))
                .currency("USD")
                .status(TransactionStatus.COMPLETED)
                .createdAt(Instant.now())
                .transactionDate(LocalDate.now())
                .build();

        when(transactionRepository.findByUserIdAndDateRange(eq("U100"), any(), any()))
                .thenReturn(List.of(tx));

        TransactionHistoryResponse response = transactionService.getTransactionHistory(
                "U100", LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getTransactions()).hasSize(1);
        assertThat(response.getTransactions().get(0).getDirection()).isEqualTo("DEBIT");
        assertThat(response.getTransactions().get(0).getStatus()).isEqualTo("COMPLETED");
        assertThat(response.getTransactions().get(0).getTransactionId()).isEqualTo("TX-001");
    }

    @Test
    void getTransactionHistory_asReceiver_returnsCreditDirection() {
        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-002")
                .senderId("U200")
                .receiverId("U100")
                .amount(new BigDecimal("50.00"))
                .currency("USD")
                .status(TransactionStatus.COMPLETED)
                .createdAt(Instant.now())
                .transactionDate(LocalDate.now())
                .build();

        when(transactionRepository.findByUserIdAndDateRange(eq("U100"), any(), any()))
                .thenReturn(List.of(tx));

        TransactionHistoryResponse response = transactionService.getTransactionHistory(
                "U100", LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getTransactions()).hasSize(1);
        assertThat(response.getTransactions().get(0).getDirection()).isEqualTo("CREDIT");
    }

    @Test
    void getTransactionHistory_withFailedReason_includesReasonCode() {
        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-003")
                .senderId("U100")
                .receiverId("U200")
                .amount(new BigDecimal("9999.00"))
                .currency("USD")
                .status(TransactionStatus.REJECTED)
                .failureReason(FailureReasonCode.INSUFFICIENT_FUNDS)
                .createdAt(Instant.now())
                .transactionDate(LocalDate.now())
                .build();

        when(transactionRepository.findByUserIdAndDateRange(eq("U100"), any(), any()))
                .thenReturn(List.of(tx));

        TransactionHistoryResponse response = transactionService.getTransactionHistory(
                "U100", LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getTransactions().get(0).getReasonCode()).isEqualTo("INSUFFICIENT_FUNDS");
    }

    @Test
    void getTransactionHistory_empty_returnsEmptyList() {
        when(transactionRepository.findByUserIdAndDateRange(any(), any(), any()))
                .thenReturn(List.of());

        TransactionHistoryResponse response = transactionService.getTransactionHistory(
                "U100", LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getTransactions()).isEmpty();
    }

    @Test
    void getFailedTransactions_returnsRejectedTransactions() {
        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-004")
                .senderId("U300")
                .receiverId("U200")
                .amount(new BigDecimal("100.00"))
                .status(TransactionStatus.REJECTED)
                .failureReason(FailureReasonCode.INSUFFICIENT_FUNDS)
                .createdAt(Instant.now())
                .transactionDate(LocalDate.now())
                .build();

        when(transactionRepository.findByStatusAndTransactionDateBetweenOrderByCreatedAtDesc(
                eq(TransactionStatus.REJECTED), any(), any()))
                .thenReturn(List.of(tx));

        FailedTransactionsResponse response = transactionService.getFailedTransactions(
                LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getFailedTransactions()).hasSize(1);
        assertThat(response.getFailedTransactions().get(0).getReasonCode())
                .isEqualTo("INSUFFICIENT_FUNDS");
        assertThat(response.getFailedTransactions().get(0).getSenderId()).isEqualTo("U300");
    }

    @Test
    void getFailedTransactions_withNullFailureReason_returnsNullReasonCode() {
        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-005")
                .senderId("U100")
                .receiverId("U200")
                .amount(new BigDecimal("50.00"))
                .status(TransactionStatus.REJECTED)
                .failureReason(null)
                .createdAt(Instant.now())
                .transactionDate(LocalDate.now())
                .build();

        when(transactionRepository.findByStatusAndTransactionDateBetweenOrderByCreatedAtDesc(
                eq(TransactionStatus.REJECTED), any(), any()))
                .thenReturn(List.of(tx));

        FailedTransactionsResponse response = transactionService.getFailedTransactions(
                LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getFailedTransactions().get(0).getReasonCode()).isNull();
    }

    @Test
    void getFailedTransactions_empty_returnsEmptyList() {
        when(transactionRepository.findByStatusAndTransactionDateBetweenOrderByCreatedAtDesc(
                any(), any(), any()))
                .thenReturn(List.of());

        FailedTransactionsResponse response = transactionService.getFailedTransactions(
                LocalDate.now().minusDays(7), LocalDate.now());

        assertThat(response.getFailedTransactions()).isEmpty();
    }
}
