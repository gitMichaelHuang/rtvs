package com.example.rtvs.controller;

import com.example.rtvs.dto.FailedTransactionsResponse;
import com.example.rtvs.service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class TransactionControllerTest {

    @Autowired
    private WebApplicationContext context;

    @MockitoBean
    private TransactionService transactionService;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(SecurityMockMvcConfigurers.springSecurity())
                .build();
    }

    @Test
    @WithMockUser(username = "ANALYST1", authorities = "ROLE_ANALYST")
    void getFailedTransactions_analystRole_returns200() throws Exception {
        when(transactionService.getFailedTransactions(any(), any())).thenReturn(
                FailedTransactionsResponse.builder()
                        .failedTransactions(List.of())
                        .build()
        );

        mockMvc.perform(get("/api/v1/rtp/transactions/failed")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.failedTransactions").isArray());
    }

    @Test
    @WithMockUser(username = "ADMIN1", authorities = "ROLE_ADMIN")
    void getFailedTransactions_adminRole_returns200() throws Exception {
        when(transactionService.getFailedTransactions(any(), any())).thenReturn(
                FailedTransactionsResponse.builder()
                        .failedTransactions(List.of())
                        .build()
        );

        mockMvc.perform(get("/api/v1/rtp/transactions/failed")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "U100", authorities = "ROLE_USER")
    void getFailedTransactions_userRole_returns403() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/transactions/failed")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isForbidden());
    }

    @Test
    void getFailedTransactions_noAuthentication_returns401() throws Exception {
        mockMvc.perform(get("/api/v1/rtp/transactions/failed")
                        .param("from", "2026-01-01")
                        .param("to", "2026-03-20"))
                .andExpect(status().isUnauthorized());
    }
}
