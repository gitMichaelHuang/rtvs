package com.example.rtvs.service;

import com.example.rtvs.domain.UserAccount;
import com.example.rtvs.dto.AuthRequest;
import com.example.rtvs.dto.AuthResponse;
import com.example.rtvs.enums.AccountStatus;
import com.example.rtvs.repository.UserAccountRepository;
import com.example.rtvs.security.JwtTokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private AuthenticationManager authenticationManager;
    @Mock
    private JwtTokenProvider jwtTokenProvider;
    @Mock
    private UserAccountRepository userAccountRepository;

    @InjectMocks
    private AuthService authService;

    @Test
    void authenticate_validCredentials_returnsAuthResponse() {
        AuthRequest request = new AuthRequest();
        request.setUserId("U100");
        request.setPassword("password");

        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any())).thenReturn(auth);
        when(jwtTokenProvider.generateToken(auth)).thenReturn("jwt-token-123");
        when(userAccountRepository.findById("U100")).thenReturn(Optional.of(
                UserAccount.builder()
                        .userId("U100")
                        .role("ROLE_USER")
                        .status(AccountStatus.ACTIVE)
                        .currentBalance(BigDecimal.TEN)
                        .dailyLimit(BigDecimal.TEN)
                        .password("hashed")
                        .build()
        ));

        AuthResponse response = authService.authenticate(request);

        assertThat(response.getToken()).isEqualTo("jwt-token-123");
        assertThat(response.getUserId()).isEqualTo("U100");
        assertThat(response.getRole()).isEqualTo("ROLE_USER");
    }

    @Test
    void authenticate_badCredentials_propagatesException() {
        AuthRequest request = new AuthRequest();
        request.setUserId("U100");
        request.setPassword("wrong");

        when(authenticationManager.authenticate(any()))
                .thenThrow(new BadCredentialsException("Bad credentials"));

        assertThatThrownBy(() -> authService.authenticate(request))
                .isInstanceOf(BadCredentialsException.class);
    }

    @Test
    void authenticate_userNotFoundAfterAuth_throwsUsernameNotFoundException() {
        AuthRequest request = new AuthRequest();
        request.setUserId("U100");
        request.setPassword("password");

        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any())).thenReturn(auth);
        when(jwtTokenProvider.generateToken(auth)).thenReturn("token");
        when(userAccountRepository.findById("U100")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.authenticate(request))
                .isInstanceOf(UsernameNotFoundException.class);
    }
}
