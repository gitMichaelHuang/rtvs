package com.example.rtvs.bdd;

import com.example.rtvs.repository.UserAccountRepository;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class PaymentStepDefinitions {

    private static final ParameterizedTypeReference<Map<String, Object>> MAP_TYPE =
            new ParameterizedTypeReference<>() {};

    @LocalServerPort
    private int port;

    @Autowired
    private UserAccountRepository userAccountRepository;

    private final RestTemplate restTemplate = new RestTemplate();

    private String jwtToken;
    private ResponseEntity<Map<String, Object>> lastResponse;

    private String baseUrl() {
        return "http://localhost:" + port;
    }

    @Given("the system has been seeded with standard test accounts")
    public void theSystemHasBeenSeededWithStandardTestAccounts() {
        assertThat(userAccountRepository.findById("U100")).isPresent();
        assertThat(userAccountRepository.findById("U200")).isPresent();
    }

    @Given("user {string} is authenticated with role {string}")
    public void userIsAuthenticatedWithRole(String userId, String role) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> loginBody = Map.of("userId", userId, "password", "password");

        ResponseEntity<Map<String, Object>> loginResponse = restTemplate.exchange(
                baseUrl() + "/auth/login",
                HttpMethod.POST,
                new HttpEntity<>(loginBody, headers),
                MAP_TYPE
        );

        assertThat(loginResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
        jwtToken = (String) loginResponse.getBody().get("token");
        assertThat(jwtToken).isNotBlank();
    }

    @When("user {string} sends a payment of {string} USD to {string} with request id {string}")
    public void userSendsPayment(String senderId, String amount, String receiverId, String requestId) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(jwtToken);

        Map<String, Object> paymentBody = Map.of(
                "paymentRequestId", requestId,
                "senderId", senderId,
                "receiverId", receiverId,
                "amount", new BigDecimal(amount),
                "currency", "USD"
        );

        lastResponse = restTemplate.exchange(
                baseUrl() + "/api/v1/rtp/payments",
                HttpMethod.POST,
                new HttpEntity<>(paymentBody, headers),
                MAP_TYPE
        );
    }

    @When("the analyst queries failed transactions from {string} to {string}")
    public void theAnalystQueriesFailedTransactions(String from, String to) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(jwtToken);

        lastResponse = restTemplate.exchange(
                baseUrl() + "/api/v1/rtp/transactions/failed?from=" + from + "&to=" + to,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                MAP_TYPE
        );
    }

    @When("user {string} queries their balance")
    public void userQueriesTheirBalance(String userId) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(jwtToken);

        lastResponse = restTemplate.exchange(
                baseUrl() + "/api/v1/rtp/users/" + userId + "/balance",
                HttpMethod.GET,
                new HttpEntity<>(headers),
                MAP_TYPE
        );
    }

    @Then("the response status is {int}")
    public void theResponseStatusIs(int expectedStatus) {
        assertThat(lastResponse.getStatusCode().value()).isEqualTo(expectedStatus);
    }

    @And("the payment status is {string}")
    public void thePaymentStatusIs(String expectedStatus) {
        assertThat(lastResponse.getBody()).containsEntry("status", expectedStatus);
    }

    @And("a transactionId is present in the response")
    public void aTransactionIdIsPresentInTheResponse() {
        assertThat(lastResponse.getBody()).containsKey("transactionId");
        assertThat((String) lastResponse.getBody().get("transactionId")).isNotBlank();
    }

    @And("the reason code is {string}")
    public void theReasonCodeIs(String expectedReasonCode) {
        assertThat(lastResponse.getBody()).containsEntry("reasonCode", expectedReasonCode);
    }

    @And("the failed transactions list is present")
    public void theFailedTransactionsListIsPresent() {
        assertThat(lastResponse.getBody()).containsKey("failedTransactions");
    }

    @And("the balance response contains a currentBalance")
    public void theBalanceResponseContainsACurrentBalance() {
        assertThat(lastResponse.getBody()).containsKey("currentBalance");
    }
}
