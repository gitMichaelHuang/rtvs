package com.example.rtvs.service;

import com.example.rtvs.domain.LedgerEntry;
import com.example.rtvs.domain.RtpTransaction;
import com.example.rtvs.domain.UserAccount;
import com.example.rtvs.enums.AccountStatus;
import com.example.rtvs.enums.EntryType;
import com.example.rtvs.enums.TransactionStatus;
import com.example.rtvs.repository.LedgerEntryRepository;
import com.example.rtvs.repository.UserAccountRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LedgerPostingServiceTest {

    @Mock
    private UserAccountRepository userAccountRepository;
    @Mock
    private LedgerEntryRepository ledgerEntryRepository;

    @InjectMocks
    private LedgerPostingService ledgerPostingService;

    @Test
    void post_success_updatesBalancesAndCreatesLedgerEntries() {
        UserAccount sender = UserAccount.builder()
                .userId("U100")
                .currentBalance(new BigDecimal("500.00"))
                .status(AccountStatus.ACTIVE)
                .password("hash")
                .role("ROLE_USER")
                .dailyLimit(new BigDecimal("2000.00"))
                .build();

        UserAccount receiver = UserAccount.builder()
                .userId("U200")
                .currentBalance(new BigDecimal("100.00"))
                .status(AccountStatus.ACTIVE)
                .password("hash")
                .role("ROLE_USER")
                .dailyLimit(new BigDecimal("1000.00"))
                .build();

        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-001")
                .senderId("U100")
                .receiverId("U200")
                .amount(new BigDecimal("150.00"))
                .status(TransactionStatus.VALIDATED)
                .transactionDate(LocalDate.now())
                .createdAt(Instant.now())
                .build();

        when(userAccountRepository.findByIdForUpdate("U200")).thenReturn(Optional.of(receiver));
        when(userAccountRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(ledgerEntryRepository.saveAll(any())).thenAnswer(inv -> inv.getArgument(0));

        ledgerPostingService.post(tx, sender);

        assertThat(sender.getCurrentBalance()).isEqualByComparingTo("350.00");
        assertThat(receiver.getCurrentBalance()).isEqualByComparingTo("250.00");

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<LedgerEntry>> captor = ArgumentCaptor.forClass(List.class);
        verify(ledgerEntryRepository).saveAll(captor.capture());

        List<LedgerEntry> entries = captor.getValue();
        assertThat(entries).hasSize(2);

        LedgerEntry debit = entries.stream()
                .filter(e -> e.getEntryType() == EntryType.DEBIT)
                .findFirst().orElseThrow();
        LedgerEntry credit = entries.stream()
                .filter(e -> e.getEntryType() == EntryType.CREDIT)
                .findFirst().orElseThrow();

        assertThat(debit.getUserId()).isEqualTo("U100");
        assertThat(debit.getBalanceAfter()).isEqualByComparingTo("350.00");

        assertThat(credit.getUserId()).isEqualTo("U200");
        assertThat(credit.getBalanceAfter()).isEqualByComparingTo("250.00");
    }

    @Test
    void post_receiverNotFound_throwsIllegalStateException() {
        UserAccount sender = UserAccount.builder()
                .userId("U100")
                .currentBalance(new BigDecimal("500.00"))
                .dailyLimit(new BigDecimal("2000.00"))
                .status(AccountStatus.ACTIVE)
                .password("hash")
                .role("ROLE_USER")
                .build();

        RtpTransaction tx = RtpTransaction.builder()
                .transactionId("TX-001")
                .senderId("U100")
                .receiverId("UNKNOWN")
                .amount(new BigDecimal("100.00"))
                .status(TransactionStatus.VALIDATED)
                .createdAt(Instant.now())
                .build();

        when(userAccountRepository.findByIdForUpdate("UNKNOWN")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ledgerPostingService.post(tx, sender))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Receiver not found");
    }
}
